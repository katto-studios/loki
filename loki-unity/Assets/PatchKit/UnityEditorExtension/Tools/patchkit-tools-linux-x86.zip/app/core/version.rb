module PatchKitTools
  VERSION = '2.5.0'.freeze
end
